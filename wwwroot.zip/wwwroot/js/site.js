// Most system logic now lives in C# Razor Page handlers.
// This file is intentionally small and only supports browser-only actions.
